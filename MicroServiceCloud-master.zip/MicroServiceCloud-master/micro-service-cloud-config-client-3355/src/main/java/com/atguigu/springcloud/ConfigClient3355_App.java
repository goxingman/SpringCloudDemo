
package com.atguigu.springcloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigClient3355_App {

    public static void main(String[] args) {
        SpringApplication.run(ConfigClient3355_App.class, args);
    }

}
